﻿using System.Collections.Generic;

namespace VeraHomeAutomation.Api.MapQuest
{
    
    public class DisplayLatLng
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class Location
    {
        public DisplayLatLng displayLatLng { get; set; }
    }

    public class Result
    {
        public List<Location> locations { get; set; }
    }

    public class MapQuestDataModel
    {
        public List<Result> results { get; set; }
    }
}
