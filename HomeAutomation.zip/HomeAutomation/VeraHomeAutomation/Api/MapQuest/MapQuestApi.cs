﻿using System.Threading.Tasks;
using MediaBrowser.Model.Serialization;

namespace VeraHomeAutomation.Api.MapQuest
{
    public class MapQuestApi
    {
        private static readonly IJsonSerializer JSonSerializer = VeraHomeAutomationServerEntryPoint.JSonSerializer;
        public static async Task<MapQuestDataModel> GetGeoCoding(string location)
        {
            var json = await PluginHttpClient.GetStream(
                "http://www.mapquestapi.com/geocoding/v1/address?key=g0lBCgI9zelMCGl2qBgGAKLPstsn4Axs&location=" +
                location);
            return JSonSerializer.DeserializeFromString<MapQuestDataModel>(json);
        }
    }
}
