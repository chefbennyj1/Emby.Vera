﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediaBrowser.Model.Serialization;

namespace VeraHomeAutomation.Api.Vera
{
    public class VeraApi
    {
        private static readonly IJsonSerializer JSonSerializer = VeraHomeAutomationServerEntryPoint.JSonSerializer;


        public static VeraDeviceInfo VeraDeviceInfo { get; set; }

        private const string V7Url = @"https://vera-us-oem-authd.mios.com/locator/locator/locator";

        private const string V5Url = @"https://sta1.mios.com/locator_json.php";

        public static async Task<bool> DeviceReadyAsync(string ipAddress)
        {
            return await PluginHttpClient.GetStream(@"http://" + ipAddress + ":3480/data_request?id=alive") == ("OK");
        }

        private static async Task<Version5> LocateVeraVersion5DeviceAsync()
        {
            var jSon = string.Empty;
            try
            {
                jSon = await PluginHttpClient.GetStream(V5Url);
            }
            catch { }
            return JSonSerializer.DeserializeFromString<Version5>(jSon);
        }

        private static async Task<Version7> LocateVeraVersion7DeviceAsync()
        {
            var jSon = string.Empty;
            try
            {
                jSon =
                    await PluginHttpClient.GetStream(V7Url);
            }
            catch { }
            return JSonSerializer.DeserializeFromString<Version7>(jSon);

        }

        public static async Task<VeraNetworkDataModel> GetNetworkDataAsync(string ip)
        {
            try
            {
                return JSonSerializer.DeserializeFromString<VeraNetworkDataModel>(await PluginHttpClient.GetStream("http://" + ip + ":3480/data_request?id=sdata"));
            }
            catch { return null; }
        }

        public static async Task<List<VeraDevice>> GetVeraDevices()
        {
            try
            {
                var json =
                    await PluginHttpClient.GetStream(V7Url);

                if (json.Equals(string.Empty)) return null;

                Version7 deviceInfoUi7 = await LocateVeraVersion7DeviceAsync();
                return deviceInfoUi7.Devices;

            }
            catch
            {

            }

            return null;
        }

        public static async Task<string> GetFirstOrDefaultVeraDeviceIp()
        {
            bool IsUi5(string s) => s.Trim() == "{}";
            try
            {
                var json =
                    await PluginHttpClient.GetStream(V7Url);

                if (json.Equals(string.Empty)) return "error";

                switch (IsUi5(json))
                {
                    case true:
                        //Log.Info("Found Vera UI5");
                        Version5 deviceInfoUi5 = await LocateVeraVersion5DeviceAsync();
                        Unit veraDeviceUi5 = deviceInfoUi5.units.FirstOrDefault();
                        if (veraDeviceUi5 != null)
                            return veraDeviceUi5.ipAddress;
                        break;
                    case false:
                        //Log.Info("Found Vera UI7");
                        Version7 deviceInfoUi7 = await LocateVeraVersion7DeviceAsync();
                        VeraDevice veraDeviceUi7 = deviceInfoUi7.Devices.FirstOrDefault();
                        if (veraDeviceUi7 != null)
                            return veraDeviceUi7.InternalIP;
                        break;
                }
            }
            catch
            {
                return "error";
            }
            return "error";
        }

        private static string GetVeraImageUrl(string model)
        {
            switch (model)
            {
                case "VeraLite":
                    {
                        return "https://home.getvera.com/assets/portal_getvera_ui7/images/veralite_front.jpg";
                    }

                case "VeraEdge":
                    {
                        return "https://home.getvera.com/assets/portal_getvera_ui7/images/veraedge_front.jpg";
                    }

                case "VeraLite G":
                    {
                        return "https://home.getvera.com/assets/portal_getvera_ui7/images/veraliteg_front.jpg";
                    }

                default:
                    return "http://getvera.com/wp-content/uploads/VeraPlus_Controller_TOP_LEDs-640x640.jpg";
            }
        }

        public static string GetVeraName(string model)
        {

            if (model.Contains("G450"))
            {
                return "Vera Plus";
            }

            if (model.Contains("NA900"))
            {
                return "Vera 3";
            }

            if (model.Contains("NA301"))
            {
                return "Vera Edge";
            }

            if (model.Contains("G550"))
            {
                return "Vera Plus";
            }
            return "Vera Edge";

        }

        public static async Task<VeraDeviceInfo> GetVeraDeviceInfoAsync(string ipAddress = null)
        {
            var ip = ipAddress ?? await GetFirstOrDefaultVeraDeviceIp();

            var networkData = await GetNetworkDataAsync(ip);
            
            VeraDeviceInfo =  new VeraDeviceInfo()
            {
                InternalIp = ip,
                Scenes = networkData.scenes,
                Type = networkData.model,
                SerialNumber = networkData.serial_number,
                ImageUrl = GetVeraImageUrl(networkData.model),
                Name = GetVeraName(networkData.model)
            };
            return VeraDeviceInfo;
        }

    }


}
