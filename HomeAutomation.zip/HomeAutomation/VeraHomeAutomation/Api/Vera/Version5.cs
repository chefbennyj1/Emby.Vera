﻿using System.Collections.Generic;

namespace VeraHomeAutomation.Api.Vera
{
    // ReSharper disable InconsistentNaming
    public class ForwardServer
    {

        public string hostName { get; set; }
        public bool primary { get; set; }
    }

    public class Unit
    {
        public string serialNumber { get; set; }
        public string FirmwareVersion { get; set; }
        public object name { get; set; }
        public string ipAddress { get; set; }
        public List<string> users { get; set; }
        public string active_server { get; set; }
        public List<ForwardServer> forwardServers { get; set; }
    }

    public class Version5
    {
        public List<Unit> units { get; set; }
    }

}
