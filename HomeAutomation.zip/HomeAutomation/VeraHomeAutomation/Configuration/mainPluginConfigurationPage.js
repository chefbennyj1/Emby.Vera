﻿
define(['libraryMenu'],
    function (libraryMenu) {

        var pluginId = "df04d306-8cbb-49d5-9107-20581aacf86f";
       

        function getClientHtml(device) {

            var html = "";
            html += '<div class="clientButtonContainer" style="padding-bottom: 2%">';
            html += '<div data-name="' + device.Name + '" data-id="' + device.Id + '" data-app="' + device.AppName + '" style="border-radius: 2px; border: 1px solid rgba(0,0,0,0.158)" class="clientProfile listItem">';
            html += '<img style="float-left; width:3%;" src="' + deviceNameImage(device.Name, device.AppName) + '" />';
            html += '<div class="listItemBody">';
            html += '<h3 class="listItemBodyText">' + device.Name + ' - ' + device.AppName + '</h3>';
            html += '</div>';
            html += '<i class="md-icon btnDeleteProfile" data-index="0">close</i>';
            html += '</div>';
            html += '</div>';

            return html;
        };

        function deviceNameImage(deviceName, deviceAppName) {

            if (deviceName.toLowerCase().indexOf("xbox") > -1)       return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/xboxone.png";
            
            if (deviceName.toLowerCase().indexOf("roku") > -1)       return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/roku.png";
            
            if (deviceName.toLowerCase().indexOf("chrome") > -1)     return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/chrome.png";
            
            if (deviceName.toLowerCase().indexOf("firefox") > -1)    return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/firefox.png";
            
            if (deviceAppName.toLowerCase().indexOf("android") > -1) return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/android.png";
            
            if (deviceName.toLowerCase().indexOf("edge") > -1)       return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/edge.png";
            
            if (deviceName.toLowerCase().indexOf("amazon") > -1)     return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/amazon.png";
            
            if (deviceName.toLowerCase().indexOf("apple") > -1)      return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/appletev.png";
            
            if (deviceName.toLowerCase().indexOf("windows") > -1)    return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/windowsrt.png";
            
            if (deviceName.toLowerCase().indexOf("dlna") > -1)       return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/dlna.png";
            
            if (deviceName.toLowerCase().indexOf("chromecast") > -1) return "https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/chromecast.png";



            return "https://github.com/MediaBrowser/Emby.Resources/blob/master/images/Logos/logoicon.png";
        }

        function loadPageData(view, config) {

            //setOptionalVeraDeviceIpEnabledStyles(view);

            var activeMessage = view.querySelector('#activeMessage');
            var veraDash = view.querySelector("#veraDash");

            return new Promise(() => {

                ApiClient.getJSON(ApiClient.getUrl("Header")).then(
                    (imgInfo) => {
                        veraDash.style.backgroundImage =
                            "url('data:image/png;base64," + imgInfo.Image + "')";
                    });

                ApiClient.getJSON(ApiClient.getUrl("VeraModelInfo")).then(
                    (modelInfo) => {
                        var html = '';

                        html += '<span id="icnConnectedContainer" style="color: white; opacity:0; padding-right: 3%;">';
                        html += '<i class="md-icon" style="padding-bottom: 0.5%;">';
                        html += 'check_circle_outline';
                        html += '</i>';
                        html += '</span > ';
                        html += modelInfo.Name;
                        html += ': ';
                        html += modelInfo.InternalIp;
                        activeMessage.style.opacity = 0;
                        activeMessage.innerHTML = html;
                        activeMessage.style.color = 'white';

                        try {
                            activeMessage.animate(
                                {
                                    transform: ['translateX(-200px)', 'translateX(0)'],
                                    opacity: [0, 1]
                                },
                                {
                                    duration: 300,
                                    fill: 'forwards',
                                    easing: 'cubic-bezier(0.42, 0, 0.58, 1)',
                                    delay: 525
                                });
                        } catch (err) {
                            activeMessage.style.opacity = 1;
                        }

                        var iconConnectContainer = view.querySelector('#icnConnectedContainer');
                        try {
                            iconConnectContainer.animate(
                                {
                                    opacity: [0, 1]
                                },
                                {
                                    duration: 320,
                                    fill: 'forwards',
                                    easing: 'cubic-bezier(0.42, 0, 0.58, 1)',
                                    delay: 880
                                });
                        } catch (err) {
                            iconConnectContainer.style.opacity = 1;
                        }
                        
                        if (config.SavedDeviceProfiles) {
                            config.SavedDeviceProfiles.forEach(
                                (device) => {
                                    view.querySelector('#clientProfiles').innerHTML += (getClientHtml(device));
                                });
                        }
                    
                    }, () => { 

                        var html = '';
                        html += '<span style="color: red" >';
                        html += '<i class="md-icon">';
                        html += 'error';
                        html += '</i>';
                        html += '<span>';
                        html += ' No Vera Home Automation Device Detected!';

                        activeMessage.innerHTML     = html;
                        activeMessage.style.color   = 'red';
                        activeMessage.style.opacity = 1;
                        activeMessage.style.display = 'block';

                    });

                var veraDeviceIps = view.querySelector('#veraDeviceIps');
                if (veraDeviceIps.length > 0) {
                    removeOptionsFromSelect(veraDeviceIps);
                }

                ApiClient.getJSON(ApiClient.getUrl("VeraDeviceList")).then(
                    (veraDevices) => {
                        veraDevices.forEach(
                            (device) => {
                                ApiClient.getJSON(ApiClient.getUrl("GetName?IpAddress=" + device.InternalIP)).then(
                                    (result) => {
                                        veraDeviceIps.innerHTML += ('<option value="' + device.InternalIP + '">' + device.InternalIP + ' - ' + result.Name + '</option>');
                                    });
                            });
                  
                    });
                if (config.SaveVeraDeviceIp) {
                    veraDeviceIps.value = config.SaveVeraDeviceIp;
                }



                var deviceNameSelect = view.querySelector('#deviceName');
                if (deviceNameSelect.length > 0) {
                    removeOptionsFromSelect('#deviceName');
                }

                ApiClient.getJSON(ApiClient.getUrl("EmbyDeviceList")).then(
                    (devices) => {
                        devices.forEach(
                            (device) => {
                                deviceNameSelect.innerHTML +=
                                    ('<option value="' + device.Name + '" data-app="' + device.AppName + '" data-name="' + device.Name + '">' + device.Name + ' - ' + device.AppName + '</option>');
                            });
                    });


                ApiClient.getJSON(ApiClient.getUrl("LiveTvTunerName")).then(
                    (result) => {
                        if (result.Name !== "") {
                            view.querySelector('#tuner').innerHTML = '<i style="padding-bottom:1%" class="md-icon">live_tv</i> ' + result.Name;
                            view.querySelector('#LiveTvPlaybackStarted').disabled  = false;
                            view.querySelector('#LiveTvPlaybackStopped').disabled  = false;
                            view.querySelector('#LiveTvPlaybackPaused').disabled   = false;
                            view.querySelector('#LiveTvPlaybackUnPaused').disabled = false;
                        }
                    });

            });
        }

        function getCoordinateHtml(location) {
            var html = '';
            html += '<i class="md-icon">place</i>';
            html += '<span> Longitude: ' + location.Longitude + '</span>';
            html += '<span> Latitude : ' + location.Latitude  + '</span>';
            return html;
        } 

        function removeOptionsFromSelect(selectbox) {
            if (selectbox.options.length > 0) {
                for (var i = selectbox.options.length - 1; i >= 0; i--) {
                    selectbox.remove(i);
                }
            }
        }

        function loadConfig(view) {
            ApiClient.getPluginConfiguration(pluginId).then(
                (config) => {
                    loadPageData(view, config);
                    Dashboard.hideLoadingMsg;
                });
        }

        return function (view) {
            
            view.addEventListener('viewshow',
                () => {

                    loadConfig(view);

                    
                    window.addEventListener('resize',
                        () => {
                            if (window.matchMedia("(max-width: 800px)").matches) {
                                view.querySelector('#activeMessage').style.display = 'none';
                            } else {
                                view.querySelector('#activeMessage').style.display = 'block';
                            }
                        });
                    
                    view.querySelector("#showMovieList").addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#tvSceneList').style.display      = 'none';
                            view.querySelector('#movieSceneList').style.display   = 'block';
                            view.querySelector('#musicSceneList').style.display   = 'none';
                            view.querySelector('#sessionSceneList').style.display = 'none';
                            view.querySelector('#Schedule').style.display         = 'none';
                            view.querySelector('#liveTvSceneList').style.display  = 'none';
                        });

                    view.querySelector("#showTvList").addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#tvSceneList').style.display      = 'block';
                            view.querySelector('#movieSceneList').style.display   = 'none';
                            view.querySelector('#musicSceneList').style.display   = 'none';
                            view.querySelector('#sessionSceneList').style.display = 'none';
                            view.querySelector('#Schedule').style.display         = 'none';
                            view.querySelector('#liveTvSceneList').style.display  = 'none';
                        });

                    view.querySelector("#showMusicList").addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#tvSceneList').style.display      = 'none';
                            view.querySelector('#movieSceneList').style.display   = 'none';
                            view.querySelector('#musicSceneList').style.display   = 'block';
                            view.querySelector('#sessionSceneList').style.display = 'none';
                            view.querySelector('#Schedule').style.display         = 'none';
                            view.querySelector('#liveTvSceneList').style.display  = 'none';
                        });

                    view.querySelector("#showSessionList").addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#tvSceneList').style.display      = 'none';
                            view.querySelector('#movieSceneList').style.display   = 'none';
                            view.querySelector('#musicSceneList').style.display   = 'none';
                            view.querySelector('#sessionSceneList').style.display = 'block';
                            view.querySelector('#Schedule').style.display         = 'none';
                            view.querySelector('#liveTvSceneList').style.display  = 'none';
                        });

                    view.querySelector('#showLiveTvList').addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#tvSceneList').style.display      = 'none';
                            view.querySelector('#movieSceneList').style.display   = 'none';
                            view.querySelector('#musicSceneList').style.display   = 'none';
                            view.querySelector('#sessionSceneList').style.display = 'none';
                            view.querySelector('#Schedule').style.display         = 'none';
                            view.querySelector('#liveTvSceneList').style.display  = 'block';
                        });

                    view.querySelector("#showSchedule").addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#tvSceneList').style.display      = 'none';
                            view.querySelector('#movieSceneList').style.display   = 'none';
                            view.querySelector('#musicSceneList').style.display   = 'none';
                            view.querySelector('#sessionSceneList').style.display = 'none';
                            view.querySelector('#Schedule').style.display         = 'block';
                            view.querySelector('#liveTvSceneList').style.display  = 'none';

                        });

                    //view.querySelector('#chkOptionalVeraAddress').addEventListener('change',
                    //    () => {

                    //        var chkOptionalVeraAddress = view.querySelector('#chkOptionalVeraAddress');
                    //        var optionalId = view.querySelector('#optionalId');
                    //        (chkOptionalVeraAddress.checked) ? optionalId.style.display = 'block' : optionalId.style.display = 'none';

                    //        ApiClient.getPluginConfiguration(pluginId).then(function (config) {
                    //            config.UserVeraIpOverride = chkOptionalVeraAddress.checked;
                    //            ApiClient.updatePluginConfiguration(pluginId, config).then(function (result) {
                    //                Dashboard.hideLoadingMsg();
                    //                Dashboard.processPluginConfigurationUpdateResult(result);
                    //            });
                    //        });
                    //    });

                    view.querySelector('#saveButton').addEventListener('click',
                        (event) => {
                            event.preventDefault();

                            var deviceProfiles = [];
                            var pushedDevice;

                            var moviePlaybackStartedSelect   = view.querySelector('#MoviesPlaybackStarted');
                            var moviePlaybackStoppedSelect   = view.querySelector('#MoviesPlaybackStopped');
                            var moviePlaybackPausedSelect    = view.querySelector('#MoviesPlaybackPaused');
                            var moviePlaybackUnPausedSelect  = view.querySelector('#MoviesPlaybackUnPaused');

                            var seriesPlaybackStartedSelect  = view.querySelector('#SeriesPlaybackStarted');
                            var seriesPlaybackStoppedSelect  = view.querySelector('#SeriesPlaybackStopped');
                            var seriesPlaybackPausedSelect   = view.querySelector('#SeriesPlaybackPaused');
                            var seriesPlaybackUnPausedSelect = view.querySelector('#SeriesPlaybackUnPaused');

                            var musicPlaybackStartedSelect   = view.querySelector('#MusicPlaybackStarted');
                            var musicPlaybackStoppedSelect   = view.querySelector('#MusicPlaybackStopped');
                            var musicPlaybackPausedSelect    = view.querySelector('#MusicPlaybackPaused');
                            var musicPlaybackUnPausedSelect  = view.querySelector('#MusicPlaybackUnPaused');

                            var liveTvPlaybackStartedSelect  = view.querySelector('#LiveTvPlaybackStarted');
                            var liveTvPlaybackStoppedSelect  = view.querySelector('#LiveTvPlaybackStopped');
                            var liveTvPlaybackPausedSelect   = view.querySelector('#LiveTvPlaybackPaused');
                            var liveTvPlaybackUnPausedSelect = view.querySelector('#LiveTvPlaybackUnPaused');


                            var sessionStartedSelect         = view.querySelector('#SessionStarted');
                            var sessionEndedSelect           = view.querySelector('#SessionEnded');

                            var sceneScheduleInput           = view.querySelector('#ScheduleTime');
                            var enableSmartSchedule          = view.querySelector('#chkEnableSmartSchedule');
                            
                            ApiClient.getPluginConfiguration(pluginId).then(function (config) {

                                var newDeviceSetup = {
                                    Name                   : config.DeviceConfiguration.Name,
                                    Id                     : config.DeviceConfiguration.Id,
                                    AppName                : config.DeviceConfiguration.AppName,

                                    MoviesPlaybackStarted  : moviePlaybackStartedSelect.options[moviePlaybackStartedSelect.selectedIndex     >= 0 ? moviePlaybackStartedSelect.selectedIndex   : 0].value,
                                    MoviesPlaybackPaused   : moviePlaybackPausedSelect.options[moviePlaybackPausedSelect.selectedIndex       >= 0 ? moviePlaybackPausedSelect.selectedIndex    : 0].value,
                                    MoviesPlaybackStopped  : moviePlaybackStoppedSelect.options[moviePlaybackStoppedSelect.selectedIndex     >= 0 ? moviePlaybackStoppedSelect.selectedIndex   : 0].value,
                                    MoviesPlaybackUnPaused : moviePlaybackUnPausedSelect.options[moviePlaybackUnPausedSelect.selectedIndex   >= 0 ? moviePlaybackUnPausedSelect.selectedIndex  : 0].value,

                                    SeriesPlaybackStarted  : seriesPlaybackStartedSelect.options[seriesPlaybackStartedSelect.selectedIndex   >= 0 ? seriesPlaybackStartedSelect.selectedIndex  : 0].value,
                                    SeriesPlaybackPaused   : seriesPlaybackPausedSelect.options[seriesPlaybackPausedSelect.selectedIndex     >= 0 ? seriesPlaybackPausedSelect.selectedIndex   : 0].value,
                                    SeriesPlaybackStopped  : seriesPlaybackStoppedSelect.options[seriesPlaybackStoppedSelect.selectedIndex   >= 0 ? seriesPlaybackStoppedSelect.selectedIndex  : 0].value,
                                    SeriesPlaybackUnPaused : seriesPlaybackUnPausedSelect.options[seriesPlaybackUnPausedSelect.selectedIndex >= 0 ? seriesPlaybackUnPausedSelect.selectedIndex : 0].value,

                                    MusicPlaybackStarted   : musicPlaybackStartedSelect.options[musicPlaybackStartedSelect.selectedIndex     >= 0 ? musicPlaybackStartedSelect.selectedIndex   : 0].value,
                                    MusicPlaybackPaused    : musicPlaybackPausedSelect.options[musicPlaybackPausedSelect.selectedIndex       >= 0 ? musicPlaybackPausedSelect.selectedIndex    : 0].value,
                                    MusicPlaybackStopped   : musicPlaybackStoppedSelect.options[musicPlaybackStoppedSelect.selectedIndex     >= 0 ? musicPlaybackStoppedSelect.selectedIndex   : 0].value,
                                    MusicPlaybackUnPaused  : musicPlaybackUnPausedSelect.options[musicPlaybackUnPausedSelect.selectedIndex   >= 0 ? musicPlaybackUnPausedSelect.selectedIndex  : 0].value,

                                    LiveTvPlaybackStarted  : liveTvPlaybackStartedSelect.options[liveTvPlaybackStartedSelect.selectedIndex   >= 0 ? liveTvPlaybackStartedSelect.selectedIndex  : 0].value,
                                    LiveTvPlaybackPaused   : liveTvPlaybackPausedSelect.options[liveTvPlaybackPausedSelect.selectedIndex     >= 0 ? liveTvPlaybackPausedSelect.selectedIndex   : 0].value,
                                    LiveTvPlaybackStopped  : liveTvPlaybackStoppedSelect.options[liveTvPlaybackStoppedSelect.selectedIndex   >= 0 ? liveTvPlaybackStoppedSelect.selectedIndex  : 0].value,
                                    LiveTvPlaybackUnPaused : liveTvPlaybackUnPausedSelect.options[liveTvPlaybackUnPausedSelect.selectedIndex >= 0 ? liveTvPlaybackUnPausedSelect.selectedIndex : 0].value,
                                      
                                    SessionStarted         : sessionStartedSelect.options[sessionStartedSelect.selectedIndex                 >= 0 ? sessionStartedSelect.selectedIndex         : 0].value,
                                    SessionEnded           : sessionEndedSelect.options[sessionEndedSelect.selectedIndex                     >= 0 ? sessionEndedSelect.selectedIndex           : 0].value,

                                    SceneSchedule          : sceneScheduleInput.value,
                                    EnableSmartSchedule    : enableSmartSchedule.checked

                                };

                                deviceProfiles.push(newDeviceSetup);

                                if (config.SavedDeviceProfiles) {
                                    config.SavedDeviceProfiles.forEach(function (c) {
                                        if (c.Name !== config.DeviceConfiguration.Name &&
                                            c.AppName !== config.DeviceConfiguration.AppName) {
                                            pushedDevice = {
                                                Name                   : c.Name,
                                                Id                     : c.Id,
                                                AppName                : c.AppName,
                                                MoviesPlaybackStarted  : c.MoviesPlaybackStarted,
                                                MoviesPlaybackStopped  : c.MoviesPlaybackStopped,
                                                MoviesPlaybackPaused   : c.MoviesPlaybackPaused,
                                                MoviesPlaybackUnpaused : c.MoviesPlaybackUnpaused,
                                                SeriesPlaybackStarted  : c.SeriesPlaybackStarted,
                                                SeriesPlaybackStopped  : c.SeriesPlaybackStopped,
                                                SeriesPlaybackPaused   : c.SeriesPlaybackPaused,
                                                SeriesPlaybackUnpaused : c.SeriesPlaybackUnpaused,
                                                MusicPlaybackStarted   : c.MusicPlaybackStarted,
                                                MusicPlaybackStopped   : c.MusicPlaybackStopped,
                                                MusicPlaybackPaused    : c.MusicPlaybackPaused,
                                                MusicPlaybackUnpaused  : c.MusicPlaybackUnpaused,
                                                LiveTvPlaybackStarted  : c.LiveTvPlaybackStarted,
                                                LiveTvPlaybackStopped  : c.LiveTvPlaybackStopped,
                                                LiveTvPlaybackPaused   : c.LiveTvPlaybackPaused,
                                                LiveTvPlaybackUnpaused : c.LiveTvPlaybackUnpaused,
                                                SessionEnded           : c.SessionEnded,
                                                SessionStarted         : c.SessionStarted,
                                                SceneSchedule          : c.SceneSchedule,
                                                EnableSmartSchedule    : c.EnableSmartSchedule
                                            };
                                            deviceProfiles.push(pushedDevice);
                                        }
                                    });
                                }

                                Dashboard.alert({
                                    title: config.DeviceConfiguration.AppName + " on " + config.DeviceConfiguration.Name + " will now trigger home automation events!",
                                    message: ""
                                });

                                config.SavedDeviceProfiles = deviceProfiles;
                                config.DeviceConfiguration = { Name: null, Id: null, AppName: null };
                                
                                ApiClient.updatePluginConfiguration(pluginId, config).then(function (result) {
                                    Dashboard.processPluginConfigurationUpdateResult(result);
                                });

                                view.querySelector("#ClientSetup").style.display        = 'none';
                                //view.querySelector('#enableOptionVeraIp').style.display = 'block';
                                view.querySelector('#deviceTypes').style.display        = 'block';
                                //setOptionalVeraDeviceIpEnabledStyles(view);
                            });
                            return false;
                        });

                    view.querySelector('#veraDeviceIps').addEventListener('change',
                        () => {
                            ApiClient.getPluginConfiguration(pluginId).then(
                                (config) => {
                                    config.SaveVeraDeviceIp = view.querySelector('#veraDeviceIps').value;

                                    ApiClient.updatePluginConfiguration(pluginId, config).then(
                                        (result) => {
                                            Dashboard.hideLoadingMsg();
                                            Dashboard.processPluginConfigurationUpdateResult(result);
                                        });
                                });
                        });

                    view.querySelector('#addButton').addEventListener('click',
                        () => {
                            var deviceNameSelect = view.querySelector('#deviceName');

                            var deviceName = deviceNameSelect.options[deviceNameSelect.selectedIndex >= 0 ? deviceNameSelect.selectedIndex : 0].dataset.name;
                            var deviceApp  = deviceNameSelect.options[deviceNameSelect.selectedIndex >= 0 ? deviceNameSelect.selectedIndex : 0].dataset.app;
                            //var deviceName = //$('#deviceName option:selected').data("name");
                            //var deviceApp  = $('#deviceName option:selected').data("app");

                            ApiClient.getPluginConfiguration(pluginId).then((config) => {
                                ApiClient.getJSON(ApiClient.getUrl("EmbyDeviceList")).then(
                                    (devices) => {

                                        devices.forEach((deviceProfile) => {

                                            if (deviceProfile.Name === deviceName &&
                                                deviceProfile.AppName === deviceApp) {

                                                config.SavedDeviceProfiles.push({
                                                    Name                   : deviceProfile.Name,
                                                    Id                     : deviceProfile.Id,
                                                    AppName                : deviceProfile.AppName,
                                                    MoviesPlaybackStarted  : "",
                                                    MoviesPlaybackStopped  : "",
                                                    MoviesPlaybackPaused   : "",
                                                    MoviesPlaybackUnpaused : "",
                                                    SeriesPlaybackStarted  : "",
                                                    SeriesPlaybackStopped  : "",
                                                    SeriesPlaybackPaused   : "",
                                                    SeriesPlaybackUnpaused : "",
                                                    MusicPlaybackStarted   : "",
                                                    MusicPlaybackStopped   : "",
                                                    MusicPlaybackPaused    : "",
                                                    MusicPlaybackUnpaused  : "",
                                                    SessionEnded           : "",
                                                    SessionStarted         : "",
                                                    SceneSchedule          : ""
                                                });

                                                config = {
                                                    SavedDeviceProfiles: config.SavedDeviceProfiles
                                                };

                                                ApiClient.updatePluginConfiguration(pluginId, config).then(
                                                    (result) => {
                                                        Dashboard.processPluginConfigurationUpdateResult(result);
                                                    });

                                                view.querySelector('#clientProfiles').innerHTML += (getClientHtml(deviceProfile));
                                            }
                                        });
                                    });
                            });
                        });

                    view.querySelector('#clientProfiles').addEventListener('click',
                        (e) => {

                            if (e.target.classList.contains('btnDeleteProfile')) {

                                // the device name the user wants to remove from configuration
                                var name = e.target.closest('div').dataset.name;
                                var id   = e.target.closest('div').dataset.id;

                                // Our list of devices to write to the Configuration
                                var devices = [];
                                // Our list of devices that already exist - with the exception of the device which was just removed from the list
                                ApiClient.getPluginConfiguration(pluginId).then((config) => {
                                    config.SavedDeviceProfiles.forEach((c) => {
                                        if (c.Name !== name && c.Id !== id) {
                                            devices.push(c);
                                        }
                                    });
                                    config.SavedDeviceProfiles = devices;
                                    ApiClient.updatePluginConfiguration(pluginId, config).then(
                                        (result) => {
                                            Dashboard.hideLoadingMsg();
                                            Dashboard.processPluginConfigurationUpdateResult(result);
                                        });
                                });

                                //e.target.closest('div').remove();
                                e.target.closest('div.clientButtonContainer').remove();
                                return false;

                            }

                            if (e.target.closest('div > .clientProfile')) {

                                Dashboard.showLoadingMsg();

                                var ele         = e.target.closest('div > .clientProfile');
                                // Retrieve name and id info about the Media Browser Network Device the user has clicked on
                                var profileId   = ele.dataset.id;
                                var profileName = ele.dataset.name;
                                var profileApp  = ele.dataset.app;

                                view.querySelector('#headerTitle').innerHTML = ('Authorize  ' + profileApp + ' on ' +  profileName +  ' to trigger Vera Scenes');

                                var clientImage           = view.querySelector('#clientImage');
                                clientImage.src           = deviceNameImage(profileName, profileApp);
                                clientImage.style.opacity = 0.26;

                                var moviePlaybackStartedSelect   = view.querySelector('#MoviesPlaybackStarted');
                                var moviePlaybackStoppedSelect   = view.querySelector('#MoviesPlaybackStopped');
                                var moviePlaybackPausedSelect    = view.querySelector('#MoviesPlaybackPaused');
                                var moviePlaybackUnPausedSelect  = view.querySelector('#MoviesPlaybackUnPaused');

                                var seriesPlaybackStartedSelect  = view.querySelector('#SeriesPlaybackStarted');
                                var seriesPlaybackStoppedSelect  = view.querySelector('#SeriesPlaybackStopped');
                                var seriesPlaybackPausedSelect   = view.querySelector('#SeriesPlaybackPaused');
                                var seriesPlaybackUnPausedSelect = view.querySelector('#SeriesPlaybackUnPaused');

                                var musicPlaybackStartedSelect   = view.querySelector('#MusicPlaybackStarted');
                                var musicPlaybackStoppedSelect   = view.querySelector('#MusicPlaybackStopped');
                                var musicPlaybackPausedSelect    = view.querySelector('#MusicPlaybackPaused');
                                var musicPlaybackUnPausedSelect  = view.querySelector('#MusicPlaybackUnPaused');

                                var sessionStartedSelect         = view.querySelector('#SessionStarted');
                                var sessionEndedSelect           = view.querySelector('#SessionEnded');

                                var liveTvPlaybackStartedSelect  = view.querySelector('#LiveTvPlaybackStarted');
                                var liveTvPlaybackStoppedSelect  = view.querySelector('#LiveTvPlaybackStopped');
                                var liveTvPlaybackPausedSelect   = view.querySelector('#LiveTvPlaybackPaused');
                                var liveTvPlaybackUnPausedSelect = view.querySelector('#LiveTvPlaybackUnPaused');

                                var scheduleTime                 = view.querySelector('#ScheduleTime');

                                var smartScheduleEnabled         = view.querySelector('#chkEnableSmartSchedule');
                                var geoLocationData              = view.querySelector('#geoLocationData');
                                var cityName                     = view.querySelector('#cityName');
                                var coordinates                  = view.querySelector('#coordinates');


                                // z-wave engine could be reloading if the user just created a new scene or removed one -  may have to wait!          
                                var timerId = setInterval(() => {
                                    ApiClient.getJSON(ApiClient.getUrl("VeraAlive")).then(
                                        (zwaveEngineLoaded) => {
                                            if (zwaveEngineLoaded === true) {
                                                clearInterval(timerId);

                                                //Movie Event Scenes
                                                removeOptionsFromSelect(moviePlaybackStartedSelect);
                                                removeOptionsFromSelect(moviePlaybackStoppedSelect);
                                                removeOptionsFromSelect(moviePlaybackPausedSelect);
                                                removeOptionsFromSelect(moviePlaybackUnPausedSelect);

                                                // Append an empty option for the purpose of the user selecting no scene events.
                                                moviePlaybackStartedSelect.innerHTML  += ('<option value=""></option>');
                                                moviePlaybackStoppedSelect.innerHTML  += ('<option value=""></option>');
                                                moviePlaybackPausedSelect.innerHTML   += ('<option value=""></option>');
                                                moviePlaybackUnPausedSelect.innerHTML += ('<option value=""></option>');


                                                //TV Series Event Scenes
                                                removeOptionsFromSelect(seriesPlaybackStartedSelect);
                                                removeOptionsFromSelect(seriesPlaybackStoppedSelect);
                                                removeOptionsFromSelect(seriesPlaybackPausedSelect);
                                                removeOptionsFromSelect(seriesPlaybackUnPausedSelect);

                                                // Append an empty option for the purpose of the user selecting no scene events.
                                                seriesPlaybackStartedSelect.innerHTML  += ('<option value=""></option>');
                                                seriesPlaybackStoppedSelect.innerHTML  += ('<option value=""></option>');
                                                seriesPlaybackPausedSelect.innerHTML   += ('<option value=""></option>');
                                                seriesPlaybackUnPausedSelect.innerHTML += ('<option value=""></option>');


                                                //LiveTv Event Scenes
                                                removeOptionsFromSelect(liveTvPlaybackStartedSelect);
                                                removeOptionsFromSelect(liveTvPlaybackStoppedSelect);
                                                removeOptionsFromSelect(liveTvPlaybackPausedSelect);
                                                removeOptionsFromSelect(liveTvPlaybackUnPausedSelect);

                                                // Append an empty option for the purpose of the user selecting no scene events.
                                                liveTvPlaybackStartedSelect.innerHTML  += ('<option value=""></option>');
                                                liveTvPlaybackStoppedSelect.innerHTML  += ('<option value=""></option>');
                                                liveTvPlaybackPausedSelect.innerHTML   += ('<option value=""></option>');
                                                liveTvPlaybackUnPausedSelect.innerHTML += ('<option value=""></option>');


                                                //Music Event Scenes
                                                removeOptionsFromSelect(musicPlaybackStartedSelect);
                                                removeOptionsFromSelect(musicPlaybackStoppedSelect);
                                                removeOptionsFromSelect(musicPlaybackPausedSelect);
                                                removeOptionsFromSelect(musicPlaybackUnPausedSelect);

                                                // Append an empty option for the purpose of the user selecting no scene events.
                                                musicPlaybackStartedSelect.innerHTML  += ('<option value=""></option>');
                                                musicPlaybackStoppedSelect.innerHTML  += ('<option value=""></option>');
                                                musicPlaybackPausedSelect.innerHTML   += ('<option value=""></option>');
                                                musicPlaybackUnPausedSelect.innerHTML += ('<option value=""></option>');


                                                // Session Event Scenes
                                                removeOptionsFromSelect(sessionStartedSelect);
                                                removeOptionsFromSelect(sessionEndedSelect);

                                                // Append an empty option for the purpose of the user selecting no scene events.
                                                sessionStartedSelect.innerHTML += ('<option value=""></option>');
                                                sessionEndedSelect.innerHTML   += ('<option value=""></option>');


                                                //Put the List of Scenes in the Selection Box
                                                ApiClient.getJSON(ApiClient.getUrl("VeraSceneList")).then(
                                                    (scenes) => {
                                                        if (scenes.length > 0) {
                                                            scenes.forEach((scene) => {
                                                                moviePlaybackStartedSelect.innerHTML   += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                moviePlaybackStoppedSelect.innerHTML   += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                moviePlaybackPausedSelect.innerHTML    += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                moviePlaybackUnPausedSelect.innerHTML  += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                seriesPlaybackStartedSelect.innerHTML  += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                seriesPlaybackStoppedSelect.innerHTML  += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                seriesPlaybackPausedSelect.innerHTML   += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                seriesPlaybackUnPausedSelect.innerHTML += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                liveTvPlaybackStartedSelect.innerHTML  += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                liveTvPlaybackStoppedSelect.innerHTML  += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                liveTvPlaybackPausedSelect.innerHTML   += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                liveTvPlaybackUnPausedSelect.innerHTML += ('<option value="' + scene.name + '">' + scene.name + '</option>'); 
                                                                musicPlaybackStartedSelect.innerHTML   += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                musicPlaybackStoppedSelect.innerHTML   += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                musicPlaybackPausedSelect.innerHTML    += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                musicPlaybackUnPausedSelect.innerHTML  += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                sessionStartedSelect.innerHTML         += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                                sessionEndedSelect.innerHTML           += ('<option value="' + scene.name + '">' + scene.name + '</option>');
                                                            });
                                                        }
                                                    });

                                                var selectLoading = setInterval(() => {
                                                    if (moviePlaybackStartedSelect.length > 0) {
                                                        clearInterval(selectLoading);

                                                        ApiClient.getPluginConfiguration(pluginId).then(
                                                            (config) => {

                                                                // If the user has created a page for this client before, we should put the page together the way they left it.
                                                                if (config.SavedDeviceProfiles) {
                                                                    config.SavedDeviceProfiles.forEach(
                                                                        (c) => {
                                                                            if (c.Name === profileName &&
                                                                                c.AppName === profileApp) {

                                                                                // Set previously edited scenes and options

                                                                                //Movies
                                                                                moviePlaybackStartedSelect.value   = c.MoviesPlaybackStarted;
                                                                                moviePlaybackStoppedSelect.value   = c.MoviesPlaybackStopped;
                                                                                moviePlaybackPausedSelect.value    = c.MoviesPlaybackPaused;
                                                                                moviePlaybackUnPausedSelect.value  = c.MoviesPlaybackUnPaused;


                                                                                //TV Series
                                                                                seriesPlaybackStartedSelect.value  = c.SeriesPlaybackStarted;
                                                                                seriesPlaybackStoppedSelect.value  = c.SeriesPlaybackStopped;
                                                                                seriesPlaybackPausedSelect.value   = c.SeriesPlaybackPaused;
                                                                                seriesPlaybackUnPausedSelect.value = c.SeriesPlaybackUnPaused;


                                                                                //Music
                                                                                musicPlaybackStartedSelect.value   = c.MusicPlaybackStarted;
                                                                                musicPlaybackStoppedSelect.value   = c.MusicPlaybackStopped;
                                                                                musicPlaybackPausedSelect.value    = c.MusicPlaybackPaused;
                                                                                musicPlaybackUnPausedSelect.value  = c.MusicPlaybackUnPaused;

                                                                                //LiveTv
                                                                                liveTvPlaybackStartedSelect.value  = c.LiveTvPlaybackStarted;
                                                                                liveTvPlaybackStoppedSelect.value  = c.LiveTvPlaybackStopped;
                                                                                liveTvPlaybackPausedSelect.value   = c.LiveTvPlaybackPaused;
                                                                                liveTvPlaybackUnPausedSelect.value = c.LiveTvPlaybackUnPaused;


                                                                                //Sessions
                                                                                sessionStartedSelect.value         = c.SessionStarted;
                                                                                sessionEndedSelect.value           = c.SessionEnded;

                                                                                //Schedule
                                                                                smartScheduleEnabled.checked        = c.EnableSmartSchedule;

                                                                                (c.EnableSmartSchedule === true)
                                                                                    ? geoLocationData.style.display = 'block'
                                                                                    : geoLocationData.style.display = 'none';

                                                                                (c.EnableSmartSchedule  === true)
                                                                                    ? scheduleTime.style.display    = 'none'
                                                                                    : scheduleTime.style.display    = 'block';

                                                                                // GeoCoding if it has been selected before.
                                                                                if (c.EnableSmartSchedule === true && config.Location) {
                                                                                    cityName.value            = config.Location.Name;
                                                                                    coordinates.innerHTML     = getCoordinateHtml(config.Location);
                                                                                    coordinates.style.display = 'block';
                                                                                }

                                                                                scheduleTime.value = c.SceneSchedule;
                                                                            }
                                                                        });
                                                                }

                                                                var deviceConfig = {
                                                                    Name    : profileName,
                                                                    Id      : profileId,
                                                                    AppName : profileApp
                                                                };

                                                                config.DeviceConfiguration = deviceConfig;

                                                                ApiClient.updatePluginConfiguration(pluginId, config).then(function (result) { });

                                                            });
                                                    }
                                                }, 20);

                                                view.querySelector("#ClientSetup").style.display        = 'block';
                                                view.querySelector('#deviceTypes').style.display        = 'none';

                                                Dashboard.hideLoadingMsg();
                                            }
                                        });
                                },500);
                            }
                            return false;
                        });

                    view.querySelector('#closeButton').addEventListener('click',
                        (event) => {
                            event.preventDefault();
                            view.querySelector('#ClientSetup').style.display        = 'none';
                            view.querySelector('#deviceTypes').style.display        = 'block';
                            return false;
                        });

                    view.querySelector('#chkEnableSmartSchedule').addEventListener('change',
                        () => {
                            var enableSmartSchedule = view.querySelector('#chkEnableSmartSchedule');
                            ApiClient.getPluginConfiguration(pluginId).then(
                                (config) => {

                                    config.SavedDeviceProfiles.forEach(
                                        (device) => {

                                            if (device.Name    === config.DeviceConfiguration.Name &&
                                                device.AppName === config.DeviceConfiguration.AppName) {
                                                device.EnableSmartSchedule = enableSmartSchedule.checked;
                                                if (!enableSmartSchedule.checked && config.Location) {
                                                    config.Location = null;
                                                }
                                            }

                                            ApiClient.updatePluginConfiguration(pluginId, config).then(
                                                (result) => {
                                                    Dashboard.processPluginConfigurationUpdateResult(result);
                                                });
                                        });

                                    var geoLocationData = view.querySelector('#geoLocationData');

                                    (enableSmartSchedule.checked)
                                        ? geoLocationData.style.display = 'block'
                                        : geoLocationData.style.display = 'none';
                                    (enableSmartSchedule.checked)
                                        ? view.querySelector('#ScheduleTimeInput').style.display = 'none'
                                        : view.querySelector('#ScheduleTimeInput').style.display = 'block';
                                });
                        });
                         
                    view.querySelector('#searchLatLng').addEventListener('click',
                        () => {

                            var location = view.querySelector('#cityName').value;

                            ApiClient.getJSON(ApiClient.getUrl("GeoCoding?Address=" + encodeURIComponent(location))).then(
                                    (results) => {
                                        var coordinates           = view.querySelector('#coordinates');
                                        coordinates.innerHTML     = getCoordinateHtml(results);
                                        coordinates.style.display = 'block';
                                    });
                        });

                });
        }
    });


